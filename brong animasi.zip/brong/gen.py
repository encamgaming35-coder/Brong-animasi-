import json,re
D=165.825
S=[(0,"Pernah nggak kalian mendengar suara knalpot motor yang sangat keras... sampai terdengar dari kejauhan?"),
(0,"Suara seperti ini sering disebut knalpot brong."),
(0,"Tapi, sebenarnya... kenapa knalpot brong bisa menghasilkan suara yang jauh lebih keras daripada knalpot standar?"),
(1,"Untuk memahaminya, kita harus tahu dulu bagaimana mesin motor bekerja."),
(1,"Di dalam mesin, campuran udara dan bahan bakar dibakar untuk menghasilkan tenaga. Proses pembakaran ini menggerakkan piston, lalu menghasilkan gas sisa pembakaran."),
(1,"Gas tersebut kemudian keluar melalui katup buang... dan mengalir menuju saluran knalpot."),
(2,"Nah, di sinilah peran knalpot menjadi penting."),
(2,"Knalpot bukan hanya berfungsi sebagai saluran pembuangan gas. Knalpot juga berfungsi mengurangi suara yang dihasilkan oleh proses pembakaran mesin."),
(3,"Pada knalpot standar, terdapat ruang peredam dan material khusus yang membantu mengurangi gelombang suara."),
(3,"Ketika gelombang suara melewati bagian tersebut, sebagian energinya diserap atau dipantulkan... sehingga suara yang keluar menjadi lebih teredam."),
(4,"Lalu, bagaimana dengan knalpot brong?"),
(4,"Knalpot brong umumnya memiliki sistem peredaman yang berbeda, lebih sederhana, atau lebih minim dibandingkan knalpot standar."),
(4,"Akibatnya, gelombang suara dari mesin dapat keluar dengan lebih kuat."),
(4,"Itulah salah satu alasan mengapa suara knalpot brong terdengar jauh lebih keras."),
(5,"Namun, tingkat kebisingan tidak hanya ditentukan oleh jenis knalpot."),
(5,"Ada beberapa faktor lain yang ikut memengaruhi."),
(5,"Pertama, kapasitas mesin. Mesin dengan kapasitas berbeda dapat menghasilkan karakter suara yang berbeda pula."),
(5,"Kedua, putaran mesin atau RPM. Ketika putaran mesin meningkat, frekuensi dan intensitas suara juga bisa berubah."),
(5,"Ketiga, desain saluran knalpot. Bentuk, panjang, dan ruang di dalam knalpot dapat memengaruhi aliran gas serta karakter suara yang dihasilkan."),
(6,"Jadi, suara keras bukan berarti mesin tersebut pasti lebih bertenaga."),
(6,"Bahkan, penggunaan knalpot yang terlalu bising bisa mengganggu pengendara lain dan masyarakat di sekitar."),
(6,"Karena itu, penggunaan knalpot sebaiknya tetap memperhatikan aturan kebisingan yang berlaku."),
(7,"Kesimpulannya..."),
(7,"Knalpot brong terdengar lebih keras karena sistem peredamannya berbeda dari knalpot standar, sehingga lebih banyak energi suara yang keluar."),
(7,"Sekarang kita sudah tahu... bahwa suara knalpot bukan sekadar masalah keras atau pelan, tetapi juga berkaitan dengan proses kerja mesin dan sistem peredam suara."),
(7,"Itulah penjelasan singkat tentang mesin motor dan alasan knalpot brong bisa menghasilkan suara yang sangat keras.")]
# units: (words, weight) ; pause weights
def clauses(t):
    return [c for c in re.split(r'(?<=[.,?!])\s+|(?<=\.\.\.)\s+',t) if c]
chunks=[] # (scene,text,weight,pause_after)
for si,(sc,t) in enumerate(S):
    sents=re.split(r'(?<=[.?!])\s+',t)
    for sj,s in enumerate(sents):
        ws=s.split()
        i=0
        while i<len(ws):
            n=min(4,len(ws)-i)
            rem=len(ws)-i
            if rem==5:n=3
            elif rem<=5:n=rem
            ch=ws[i:i+n];i+=n
            end=i>=len(ws)
            chunks.append(dict(scene=sc,words=ch,pause=(0.7 if end else (0.25 if ch[-1][-1] in ',' or ch[-1].endswith('...') else 0))))
tot=sum(sum(len(w)+1.5 for w in c['words'])+c['pause']*14 for c in chunks)
k=D/tot;t=0.0
for c in chunks:
    sp=sum(len(w)+1.5 for w in c['words'])*k
    c['start']=round(t,3);c['end']=round(t+sp,3)
    ws=[];x=t
    for w in c['words']:
        d=(len(w)+1.5)*k;ws.append([w,round(x,3),round(x+d,3)]);x+=d
    c['words']=ws;t+=sp+c['pause']*14*k
    c['scene']=c['scene']
    del c['pause']
sc={}
for c in chunks:sc.setdefault(c['scene'],[c['start'],0]);sc[c['scene']][1]=c['end']
keys=sorted(sc);scenes=[]
for i,s in enumerate(keys):
    a=0 if i==0 else sc[s][0]
    b=D if i==len(keys)-1 else sc[keys[i+1]][0]
    scenes.append([s,round(a,3),round(b,3)])
open('src/data.json','w').write(json.dumps(dict(duration=D,chunks=chunks,scenes=scenes),ensure_ascii=False))
print(len(chunks),scenes)
