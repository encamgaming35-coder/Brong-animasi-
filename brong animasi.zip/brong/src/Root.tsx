import {Composition} from 'remotion';
import {Video} from './Video';
import data from './data.json';
export const Root = () => (
  <Composition id="Brong" component={Video} width={1080} height={1920} fps={30}
    durationInFrames={Math.ceil(data.duration * 30)} />
);
