import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import data from './data.json';

const C = {bg: '#0b1020', bg2: '#1a1f3a', orange: '#ff7a1a', yellow: '#ffd23f', blue: '#3fa9ff', green: '#3ddc97', red: '#ff4d5e', white: '#fff', grey: '#8b93b5'};
const FONT = 'Inter, "Helvetica Neue", Arial, sans-serif';

const Waves: React.FC<{x: number; y: number; amp: number; color: string; n?: number; dir?: number}> = ({x, y, amp, color, n = 4, dir = 1}) => {
  const f = useCurrentFrame();
  return (
    <>
      {Array.from({length: n}).map((_, i) => {
        const p = ((f / 60 + i / n) % 1);
        const r = 40 + p * 520 * amp;
        const a = (1 - p) * Math.min(1, amp) * 0.9;
        return <path key={i} d={`M ${x + dir * r * 0.5} ${y - r} A ${r} ${r} 0 0 ${dir > 0 ? 1 : 0} ${x + dir * r * 0.5} ${y + r}`}
          stroke={color} strokeWidth={14 - p * 8} fill="none" opacity={a} strokeLinecap="round" />;
      })}
    </>
  );
};

const Title: React.FC<{text: string; sub?: string; color?: string}> = ({text, sub, color = C.yellow}) => {
  const f = useCurrentFrame();
  const s = spring({frame: f, fps: 30, config: {damping: 12}});
  return (
    <div style={{position: 'absolute', top: 170, width: '100%', textAlign: 'center', fontFamily: FONT, transform: `scale(${s})`, opacity: s}}>
      <div style={{fontSize: 84, fontWeight: 900, color, letterSpacing: 2}}>{text}</div>
      {sub && <div style={{fontSize: 40, color: C.grey, marginTop: 10, fontWeight: 600}}>{sub}</div>}
    </div>
  );
};

const Pipe: React.FC<{x: number; y: number; w: number; h: number; color: string}> = ({x, y, w, h, color}) => (
  <rect x={x} y={y} width={w} height={h} rx={h / 2} fill={color} />
);

const SceneHook = () => {
  const f = useCurrentFrame();
  const shake = Math.sin(f * 1.7) * 4;
  return (
    <AbsoluteFill>
      <Title text="KNALPOT BRONG" sub="Kenapa suaranya sekeras itu?" color={C.orange} />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <g transform={`translate(${shake} 0)`}>
          <Pipe x={140} y={900} w={520} h={110} color="#555d80" />
          <rect x={620} y={880} width={110} height={150} rx={30} fill="#333a5c" />
        </g>
        <Waves x={730} y={955} amp={1.1} color={C.orange} n={5} />
      </svg>
    </AbsoluteFill>
  );
};

const SceneEngine = () => {
  const f = useCurrentFrame();
  const ph = (f / 30) * Math.PI * 2 * 1.2;
  const py = 760 + (Math.sin(ph) + 1) * 90;
  const burn = Math.sin(ph) > 0.7;
  const gasP = (f / 45) % 1;
  return (
    <AbsoluteFill>
      <Title text="DALEMAN MESIN" sub="Pembakaran → piston → gas buang" />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <rect x={340} y={640} width={400} height={480} rx={24} fill="#272d4f" stroke={C.grey} strokeWidth={6} />
        <rect x={360} y={660} width={360} height={440} fill={burn ? '#ff9a3c' : '#1a1f3a'} opacity={burn ? 0.9 : 1} />
        <rect x={380} y={py} width={320} height={80} rx={10} fill={C.blue} />
        <line x1={540} y1={py + 80} x2={540} y2={1250} stroke={C.grey} strokeWidth={16} />
        <circle cx={540} cy={1290 + Math.cos(ph) * 20} r={60} fill="#333a5c" stroke={C.grey} strokeWidth={6} />
        <text x={540} y={620} textAnchor="middle" fontSize={40} fontFamily={FONT} fontWeight={800} fill={C.white}>Udara + BBM dibakar</text>
        <rect x={740} y={690} width={200} height={60} rx={16} fill="#555d80" />
        <circle cx={760 + gasP * 360} cy={720} r={22} fill={C.grey} opacity={1 - gasP * 0.6} />
        <text x={900} y={810} textAnchor="middle" fontSize={34} fontFamily={FONT} fontWeight={700} fill={C.yellow}>katup buang</text>
        <text x={540} y={1450} textAnchor="middle" fontSize={46} fontFamily={FONT} fontWeight={900} fill={C.blue}>PISTON</text>
      </svg>
    </AbsoluteFill>
  );
};

const SceneRole = () => {
  const f = useCurrentFrame();
  const p = (f / 50) % 1;
  return (
    <AbsoluteFill>
      <Title text="PERAN KNALPOT" sub="Saluran gas + peredam suara" />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <rect x={80} y={860} width={200} height={200} rx={24} fill="#272d4f" stroke={C.grey} strokeWidth={6} />
        <text x={180} y={975} textAnchor="middle" fontSize={34} fontFamily={FONT} fontWeight={800} fill={C.white}>MESIN</text>
        <Pipe x={280} y={925} w={720} h={70} color="#555d80" />
        {[0, 1, 2].map(i => <circle key={i} cx={300 + ((p + i / 3) % 1) * 660} cy={960} r={18} fill={C.orange} />)}
        <text x={540} y={1160} textAnchor="middle" fontSize={50} fontFamily={FONT} fontWeight={900} fill={C.green}>1. Buang gas</text>
        <text x={540} y={1250} textAnchor="middle" fontSize={50} fontFamily={FONT} fontWeight={900} fill={C.blue}>2. Redam suara</text>
      </svg>
    </AbsoluteFill>
  );
};

const SceneStandard = () => (
  <AbsoluteFill>
    <Title text="KNALPOT STANDAR" sub="Ada ruang peredam & material khusus" color={C.green} />
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <rect x={90} y={820} width={700} height={240} rx={60} fill="#272d4f" stroke={C.green} strokeWidth={8} />
      {[260, 400, 540, 680].map(x => <line key={x} x1={x} y1={830} x2={x} y2={1050} stroke={C.grey} strokeWidth={10} strokeDasharray="30 14" />)}
      <rect x={790} y={920} width={150} height={40} rx={20} fill="#555d80" />
      <Waves x={940} y={940} amp={0.35} color={C.green} n={3} />
      <text x={540} y={1230} textAnchor="middle" fontSize={48} fontFamily={FONT} fontWeight={900} fill={C.white}>Gelombang suara diserap</text>
      <text x={540} y={1300} textAnchor="middle" fontSize={48} fontFamily={FONT} fontWeight={900} fill={C.green}>& dipantulkan 🔇</text>
    </svg>
  </AbsoluteFill>
);

const SceneBrong = () => (
  <AbsoluteFill>
    <Title text="KNALPOT BRONG" sub="Peredaman lebih sederhana / minim" color={C.red} />
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <Pipe x={90} y={900} w={680} h={110} color="#555d80" />
      <Pipe x={770} y={915} w={120} h={80} color="#333a5c" />
      <Waves x={890} y={955} amp={1.3} color={C.red} n={5} />
      <text x={540} y={1250} textAnchor="middle" fontSize={52} fontFamily={FONT} fontWeight={900} fill={C.white}>Energi suara keluar</text>
      <text x={540} y={1330} textAnchor="middle" fontSize={52} fontFamily={FONT} fontWeight={900} fill={C.red}>lebih kuat 🔊</text>
    </svg>
  </AbsoluteFill>
);

const cards = [['1', 'KAPASITAS MESIN', 'Karakter suara beda', C.blue], ['2', 'PUTARAN (RPM)', 'Frekuensi & intensitas berubah', C.orange], ['3', 'DESAIN SALURAN', 'Bentuk, panjang, ruang', C.green]];
const SceneFactors = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Title text="FAKTOR LAIN" sub="Bukan cuma jenis knalpot" />
      <div style={{position: 'absolute', top: 560, width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 50, fontFamily: FONT}}>
        {cards.map(([n, t, s, col], i) => {
          const sp = spring({frame: f - 60 - i * 270, fps: 30, config: {damping: 14}});
          return (
            <div key={n} style={{width: 880, padding: '40px 50px', borderRadius: 36, background: C.bg2, border: `6px solid ${col}`, transform: `translateX(${(1 - sp) * 1100}px)`, opacity: sp}}>
              <div style={{fontSize: 54, fontWeight: 900, color: col as string}}>{n}. {t}</div>
              <div style={{fontSize: 38, color: C.white, marginTop: 10}}>{s}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

const SceneRules = () => {
  const f = useCurrentFrame();
  const s = spring({frame: f, fps: 30, config: {damping: 10}});
  return (
    <AbsoluteFill>
      <Title text="KERAS ≠ BERTENAGA" sub="Bising mengganggu orang sekitar" color={C.red} />
      <div style={{position: 'absolute', top: 640, width: '100%', textAlign: 'center', fontFamily: FONT}}>
        <div style={{fontSize: 260, transform: `scale(${s})`}}>🔊</div>
        <div style={{fontSize: 56, fontWeight: 900, color: C.white, marginTop: 60}}>Patuhi aturan</div>
        <div style={{fontSize: 56, fontWeight: 900, color: C.yellow}}>batas kebisingan ⚖️</div>
      </div>
    </AbsoluteFill>
  );
};

const SceneEnd = () => {
  const f = useCurrentFrame();
  const g = interpolate(f, [0, 60], [0, 1], {extrapolateRight: 'clamp'});
  const bar = (label: string, v: number, col: string, y: number) => (
    <g>
      <text x={90} y={y - 20} fontSize={44} fontFamily={FONT} fontWeight={800} fill={C.white}>{label}</text>
      <rect x={90} y={y} width={900} height={70} rx={35} fill="#272d4f" />
      <rect x={90} y={y} width={900 * v * g} height={70} rx={35} fill={col} />
    </g>
  );
  return (
    <AbsoluteFill>
      <Title text="KESIMPULAN" sub="Peredam beda = lebih banyak energi suara keluar" />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {bar('Knalpot standar', 0.3, C.green, 800)}
        {bar('Knalpot brong', 0.95, C.red, 1020)}
        <text x={540} y={1300} textAnchor="middle" fontSize={48} fontFamily={FONT} fontWeight={900} fill={C.yellow}>Tingkat kebisingan</text>
      </svg>
    </AbsoluteFill>
  );
};

const SCENES = [SceneHook, SceneEngine, SceneRole, SceneStandard, SceneBrong, SceneFactors, SceneRules, SceneEnd];

const Subtitle: React.FC = () => {
  const {fps} = useVideoConfig();
  const t = useCurrentFrame() / fps;
  const idx = data.chunks.findIndex(c => t >= c.start && t < c.end + 0.15);
  if (idx < 0) return null;
  const c = data.chunks[idx];
  const pop = spring({frame: (t - c.start) * fps, fps, config: {damping: 12, stiffness: 220}});
  return (
    <div style={{position: 'absolute', bottom: 330, width: '100%', display: 'flex', justifyContent: 'center', padding: '0 60px'}}>
      <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0 22px', transform: `scale(${0.9 + 0.1 * pop})`, fontFamily: FONT, fontWeight: 900, fontSize: 88, textTransform: 'uppercase', lineHeight: 1.15, textAlign: 'center'}}>
        {c.words.map(([w, a, b], i) => {
          const active = t >= (a as number) && t < (b as number);
          return <span key={i} style={{color: active ? C.yellow : C.white, WebkitTextStroke: '10px #000', paintOrder: 'stroke fill', textShadow: '0 6px 0 #000', transform: active ? 'scale(1.12)' : 'none'}}>{w}</span>;
        })}
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: `linear-gradient(180deg, ${C.bg}, ${C.bg2})`}}>
    {data.scenes.map(([id, a, b]) => {
      const S = SCENES[id as number];
      const from = Math.round((a as number) * 30);
      const dur = Math.round((b as number) * 30) - from;
      return <Sequence key={id as number} from={from} durationInFrames={dur}><S /></Sequence>;
    })}
    <Subtitle />
    <Audio src={staticFile('narator_brong.mp3')} />
  </AbsoluteFill>
);
